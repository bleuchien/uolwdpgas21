# UoL Web Development

Group: web-develop-t6g8-mhl

## Content

Of the two directories
  * groundwork : contains the site analysis of five theme park web sites and the basis for our site
  * website : is the final product for the midterm submission (cross browser tested, w3c validated and verified)

And then there is a ZIP file named t6g8_everything.zip which is an archive of the above mentioned directories.
