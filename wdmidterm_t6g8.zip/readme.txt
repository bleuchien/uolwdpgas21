Coursera Static Web Page
Team : T6G8
Link : https://hub.labs.coursera.org:443/connect/sharedvtxiporr?forceRefresh=false&path=%2F
